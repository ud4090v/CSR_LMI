# zcsr.checklist — CSR Auditing Application (frontend starter)

Freestyle SAPUI5 1.108 · OData V2 `ZCSR_CHECKLIST_SRV` · governed by `CLAUDE.md`.

## Run it

```bash
npm install
npm start          # ui5 serve -o index.html → mockserver boots with the app
```

Role switch for local dev: `index.html?role=AN|RV|AD|AU` (default `AD`).
The UI5 runtime loads from the 1.108 CDN; for a tooling-managed framework see
the comment in `ui5.yaml`.

## What works today (against the mockserver)

- **Worklist**: header list with growing table, cascading LOB → Market Segment
  filters (MarketSegVH `Lob`), status via text + semantic state, role-gated
  Review/Admin buttons, navigation to detail.
- **ChecklistDetail (stub)**: bound ObjectHeader + a wiring-probe list over
  `ToItems` proving the denormalized catalog fields arrive. Procedure cards,
  autosave and Sign & Submit are the next build step (CLAUDE.md §6).
- **ReviewQueue (stub)**: SB/UR list sorted by AI flags, navigates to review
  mode. **AdminBoard (stub)**: placeholder.
- **Mockserver**: full entity sets seeded from the real catalog seed workbooks
  + ALL NINE function imports mocked, mutating mock data per the transition
  matrix. `SubmitChecklist` runs the validation mirror and answers an
  itemized OData error (`innererror/errordetails`) — the blocked-submit UX is
  testable locally. `CopyCatalogVersion` / `ReleaseCatalogVersion` behave per
  the catalog design (clone → Draft; one-way release recomputing `Editable`).

## Live service

The backend is live. To develop against it instead of the mockserver:
1. Skip `mockserver.init()` in `webapp/index.js` (or add an `?sap-ui-mock=false`
   toggle), and
2. Proxy `/sap/opu/odata` to the FES host — add a ui5 middleware proxy of your
   choice to `ui5.yaml` with the gateway host/client (not committed here since
   it is landscape-specific).

## Flags for the backend owner (raised honestly, not fixed silently)

1. **Instruction rows in `ToItems`** — CLAUDE.md §6 renders the Instructions
   panel from `ChecklistItem` rows with `Inptype === 'C'`, and this mock
   includes them. The reference ABAP `GENERATE_INSTANCES`, however, created
   `ZCSR_ITEM` records only for `INPTYPE = 'I'`. If the live service returns
   no `C` rows under `ToItems`, either the DPC should synthesize them from the
   bound catalog version, or the UI reads `QuestionSet` for the Instructions
   panel. **Verify on the first live-service smoke test** and align.
2. **`NA_ALLOWED` missing from the seed workbook** — `ZCSR_QCATALOG_seed_v0001.xlsx`
   predates the v0.2 field. Mock data uses demo values (`CSRL-P02..P04`,
   `QCLL-P02/P03` allow N/A). The seed should gain the column from the real
   template's explicit N/A permissions before catalog load.

## Next build steps (first Claude Code sessions)

1. Procedure cards on ChecklistDetail per CLAUDE.md §6 (cards, Show more,
   Example panel, N/A switch, UploadSet, autosave debounce, Sign & Submit with
   MessageManager mapping) — the mockserver already answers every path.
2. QUnit (formatter + validation mirror) and OPA5 journeys; replace the
   `npm test` / `npm run opa` placeholders (they intentionally exit 1).
3. ReviewQueue actions + AdminBoard; then live-service smoke test.
