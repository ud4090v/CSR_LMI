sap.ui.define([], function () {
	"use strict";

	/**
	 * Role helper — PROTOTYPE ONLY.
	 * UI role gating is convenience; the backend AUTHORITY-CHECK is
	 * authoritative (CLAUDE.md section 5). Against the live service the
	 * role comes from the user's ZCSR_ASSIGN records (a lightweight
	 * "my role" lookup or launchpad parameter). For local mockserver
	 * development, pick a role via URL parameter: ?role=AN|RV|AD|AU
	 */
	return {
		ROLES: { ANALYST: "AN", REVIEWER: "RV", ADMIN: "AD", AUDITOR: "AU" },

		getCurrentRole: function () {
			var sRole = new URLSearchParams(window.location.search).get("role");
			if (sRole && ["AN", "RV", "AD", "AU"].indexOf(sRole) !== -1) {
				return sRole;
			}
			return "AD"; // dev default: see every button
		}
	};
});
