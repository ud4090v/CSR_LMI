sap.ui.define([], function () {
	"use strict";

	// Fallbacks keep formatters safe when called without an i18n model
	// (e.g. QUnit without full component context).
	var mSectionFallback = { P: "Procedures", I: "Instructions / Notes" };
	var mChktypeFallback = {
		CSRM: "CSR — Market Segment",
		CSRL: "CSR — LOB",
		QCLM: "Quarter Close — Market Segment",
		QCLL: "Quarter Close — LOB"
	};

	function getBundle(oControl) {
		var oModel = oControl && oControl.getModel && oControl.getModel("i18n");
		return oModel ? oModel.getResourceBundle() : null;
	}

	return {

		/* NS->None, IP->Warning, SB/UR->Information, RT->Error, CP->Success */
		statusState: function (sStatus) {
			switch (sStatus) {
				case "IP": return "Warning";
				case "SB":
				case "UR": return "Information";
				case "RT": return "Error";
				case "CP": return "Success";
				default:   return "None";
			}
		},

		/* AI flag severity: H->Error, M->Warning, L->Information */
		severityState: function (sSeverity) {
			switch (sSeverity) {
				case "H": return "Error";
				case "M": return "Warning";
				case "L": return "Information";
				default:  return "None";
			}
		},

		/* Catalog version status (shared with the companion app): D->Warning, R->Success */
		versionState: function (sStatus) {
			return sStatus === "R" ? "Success" : (sStatus === "D" ? "Warning" : "None");
		},

		/* Section is a 1-char domain code (ZCSR_SECTION) — never shown raw */
		sectionText: function (sSection) {
			var oBundle = getBundle(this);
			if (oBundle) {
				if (sSection === "P") { return oBundle.getText("sectionProcedures"); }
				if (sSection === "I") { return oBundle.getText("sectionInstructions"); }
			}
			return mSectionFallback[sSection] || sSection || "";
		},

		/* Checklist type code -> readable text */
		chktypeText: function (sChktype) {
			var oBundle = getBundle(this);
			if (oBundle && sChktype) {
				var sText = oBundle.getText("chktype" + sChktype);
				if (sText !== "chktype" + sChktype) { return sText; }
			}
			return mChktypeFallback[sChktype] || sChktype || "";
		},

		/* Whole-LOB CSR rows carry the literal 'ALL' */
		segmentText: function (sSegment) {
			if (!sSegment) { return ""; }
			if (sSegment === "ALL") {
				var oBundle = getBundle(this);
				return oBundle ? oBundle.getText("segmentAll") : "All";
			}
			return sSegment;
		}
	};
});
