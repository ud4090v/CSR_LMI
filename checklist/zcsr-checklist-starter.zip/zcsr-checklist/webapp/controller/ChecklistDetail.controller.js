sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"zcsr/checklist/model/formatter"
], function (Controller, History, formatter) {
	"use strict";

	return Controller.extend("zcsr.checklist.controller.ChecklistDetail", {

		formatter: formatter,

		onInit: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("detail").attachPatternMatched(this._onMatched.bind(this, "edit"));
			oRouter.getRoute("detailReview").attachPatternMatched(this._onMatched.bind(this, "review"));
		},

		_onMatched: function (sMode, oEvent) {
			var sGuid = oEvent.getParameter("arguments").headerGuid;
			this.getOwnerComponent().getModel("app").setProperty("/mode", sMode);

			var oModel = this.getOwnerComponent().getModel();
			var oView = this.getView();

			oModel.metadataLoaded().then(function () {
				var sPath = "/" + oModel.createKey("ChecklistHeaderSet", {
					HeaderGuid: sGuid
				});
				oView.bindElement({
					path: sPath,
					events: {
						// Deep links from reminder e-mails: unknown or
						// unauthorized GUIDs land on NotFound.
						change: function () {
							var oCtx = oView.getElementBinding().getBoundContext();
							if (!oCtx || !oCtx.getObject()) {
								this.getOwnerComponent().getRouter()
									.getTargets().display("notFound");
							}
						}.bind(this)
					}
				});
			}.bind(this));
		},

		onNavBack: function () {
			var sPrevious = History.getInstance().getPreviousHash();
			if (sPrevious !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("worklist", {}, true);
			}
		}
	});
});
