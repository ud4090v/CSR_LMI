sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller, History) {
	"use strict";

	return Controller.extend("zcsr.checklist.controller.AdminBoard", {
		onNavBack: function () {
			var sPrevious = History.getInstance().getPreviousHash();
			if (sPrevious !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("worklist", {}, true);
			}
		}
	});
});
