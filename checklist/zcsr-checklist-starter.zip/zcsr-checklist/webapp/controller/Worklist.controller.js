sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"zcsr/checklist/model/formatter"
], function (Controller, Filter, FilterOperator, formatter) {
	"use strict";

	return Controller.extend("zcsr.checklist.controller.Worklist", {

		formatter: formatter,

		/* Cascading LOB -> Market Segment filter (MarketSegVH carries Lob) */
		onLobChange: function (oEvent) {
			var sLob = oEvent.getSource().getSelectedKey();
			var oSegment = this.byId("cbSegment");

			oSegment.setSelectedKey("");
			oSegment.setEnabled(!!sLob);
			if (sLob) {
				oSegment.getBinding("items").filter([
					new Filter("Lob", FilterOperator.EQ, sLob)
				]);
			}
			this.onFilterChange();
		},

		onFilterChange: function () {
			var aFilters = [];
			var sLob = this.byId("cbLob").getSelectedKey();
			var sSegment = this.byId("cbSegment").getSelectedKey();

			if (sLob) {
				aFilters.push(new Filter("Lob", FilterOperator.EQ, sLob));
			}
			if (sSegment) {
				aFilters.push(new Filter("MarketSeg", FilterOperator.EQ, sSegment));
			}
			this.byId("worklistTable").getBinding("items").filter(aFilters);
		},

		onClearFilters: function () {
			this.byId("cbLob").setSelectedKey("");
			var oSegment = this.byId("cbSegment");
			oSegment.setSelectedKey("");
			oSegment.setEnabled(false);
			this.byId("worklistTable").getBinding("items").filter([]);
		},

		onItemPress: function (oEvent) {
			var oHeader = oEvent.getSource().getBindingContext().getObject();
			this.getOwnerComponent().getRouter().navTo("detail", {
				headerGuid: oHeader.HeaderGuid
			});
		},

		onNavReview: function () {
			this.getOwnerComponent().getRouter().navTo("review");
		},

		onNavAdmin: function () {
			this.getOwnerComponent().getRouter().navTo("admin");
		}
	});
});
