sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("zcsr.checklist.controller.NotFound", {
		onNavBack: function () {
			this.getOwnerComponent().getRouter().navTo("worklist", {}, true);
		}
	});
});
