sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"zcsr/checklist/model/formatter"
], function (Controller, History, formatter) {
	"use strict";

	return Controller.extend("zcsr.checklist.controller.ReviewQueue", {

		formatter: formatter,

		onItemPress: function (oEvent) {
			var oHeader = oEvent.getSource().getBindingContext().getObject();
			this.getOwnerComponent().getRouter().navTo("detailReview", {
				headerGuid: oHeader.HeaderGuid
			});
		},

		onNavBack: function () {
			var sPrevious = History.getInstance().getPreviousHash();
			if (sPrevious !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("worklist", {}, true);
			}
		}
	});
});
