sap.ui.define([
	"sap/ui/core/util/MockServer"
], function (MockServer) {
	"use strict";

	var ROOT = "/sap/opu/odata/sap/ZCSR_CHECKLIST_SRV/";
	var BASE = sap.ui.require.toUrl("zcsr/checklist/localService");

	var STATUS_TEXT = {
		NS: "Not Started", IP: "In Progress", SB: "Submitted",
		UR: "Under Review", RT: "Returned", CP: "Completed"
	};

	/* Allowed-transition matrix — mirror of ZCL_CSR_MODEL->check_transition */
	var TRANSITIONS = {
		NS: ["IP"], IP: ["IP", "SB"], SB: ["UR"],
		UR: ["CP", "RT"], RT: ["IP", "SB"], CP: []
	};

	var oMockServer;

	function now() {
		return "/Date(" + Date.now() + ")/";
	}

	function getData(sSet) {
		return oMockServer.getEntitySetData(sSet);
	}

	function setData(sSet, aData) {
		oMockServer.setEntitySetData(sSet, aData);
	}

	function param(sUrl, sName) {
		// matches HeaderGuid=guid'...', Outcome='..', ValidFrom=datetime'...', Version='0002'
		var oMatch = new RegExp(sName + "=(?:guid|datetime)?'([^']*)'").exec(sUrl);
		return oMatch ? decodeURIComponent(oMatch[1]) : null;
	}

	function respondJson(oXhr, iStatus, oBody) {
		oXhr.respond(iStatus,
			{ "Content-Type": "application/json;charset=utf-8" },
			JSON.stringify(oBody));
		return true;
	}

	function odataError(oXhr, sCode, sMessage, aDetails) {
		return respondJson(oXhr, 400, {
			error: {
				code: sCode,
				message: { lang: "en", value: sMessage },
				innererror: { errordetails: aDetails || [] }
			}
		});
	}

	function findHeader(sGuid) {
		return getData("ChecklistHeaderSet").filter(function (h) {
			return h.HeaderGuid === sGuid;
		})[0];
	}

	function saveHeader(oHeader) {
		var aHeaders = getData("ChecklistHeaderSet").map(function (h) {
			return h.HeaderGuid === oHeader.HeaderGuid ? oHeader : h;
		});
		setData("ChecklistHeaderSet", aHeaders);
	}

	function setStatus(oHeader, sNew, bSign) {
		if (TRANSITIONS[oHeader.Status].indexOf(sNew) === -1) {
			return false;
		}
		oHeader.Status = sNew;
		oHeader.StatusText = STATUS_TEXT[sNew];
		oHeader.ChangedAt = now();
		if (bSign) {
			oHeader.SignedBy = oHeader.Analyst;
			oHeader.SignedAt = now();
		}
		saveHeader(oHeader);
		return true;
	}

	/* Client mirror of ZCL_CSR_VALIDATION — full failure list */
	function validate(sGuid) {
		var aFailures = [];
		var aItems = getData("ChecklistItemSet").filter(function (i) {
			return i.HeaderGuid === sGuid && i.Inptype === "I";
		});
		var aAtts = getData("AttachmentSet").filter(function (a) {
			return a.HeaderGuid === sGuid && !a.Deleted;
		});
		aItems.forEach(function (oItem) {
			var bSatisfied = !!oItem.Response ||
				(oItem.NaAllowed && oItem.NaFlag);
			if (oItem.RespRequired && !bSatisfied) {
				aFailures.push({
					code: "ZCSR/003", severity: "error",
					target: oItem.QuestionId,
					message: "Response required: " + oItem.Title
				});
			}
			if (oItem.AttachMode === "R") {
				var bHas = aAtts.some(function (a) {
					return a.QuestionId === oItem.QuestionId;
				});
				if (!bHas) {
					aFailures.push({
						code: "ZCSR/004", severity: "error",
						target: oItem.QuestionId,
						message: "Required evidence missing: " + oItem.Title
					});
				}
			}
		});
		return aFailures;
	}

	function headerAction(sUrl, oXhr, sTarget, bSign, fnExtra) {
		var sGuid = param(sUrl, "HeaderGuid");
		var oHeader = findHeader(sGuid);
		if (!oHeader) {
			return odataError(oXhr, "ZCSR/001", "Checklist " + sGuid + " not found");
		}
		if (fnExtra && fnExtra(oHeader, oXhr) === true) {
			return true; // extra handler already responded (error path)
		}
		if (sTarget && !setStatus(oHeader, sTarget, bSign)) {
			return odataError(oXhr, "ZCSR/002",
				"Status change " + oHeader.Status + " -> " + sTarget + " is not allowed");
		}
		return respondJson(oXhr, 200, { d: oHeader });
	}

	return {

		init: function () {
			oMockServer = new MockServer({ rootUri: ROOT });

			MockServer.config({ autoRespond: true, autoRespondAfter: 60 });

			oMockServer.simulate(BASE + "/metadata.xml", {
				sMockdataBaseUrl: BASE + "/mockdata",
				bGenerateMissingMockData: false
			});

			/* ---- function imports: MockServer does not auto-mock these ---- */
			var aRequests = oMockServer.getRequests();

			aRequests.push({
				method: "POST",
				path: new RegExp("SubmitChecklist(.*)"),
				response: function (oXhr, sUrlParams) {
					return headerAction(oXhr.url, oXhr, "SB", true, function (oHeader, oXhr2) {
						var aFailures = validate(oHeader.HeaderGuid);
						if (aFailures.length) {
							return odataError(oXhr2, aFailures[0].code,
								aFailures[0].message, aFailures);
						}
						return false;
					});
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("StartReview(.*)"),
				response: function (oXhr) {
					return headerAction(oXhr.url, oXhr, "UR", false);
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("CompleteReview(.*)"),
				response: function (oXhr) {
					var sOutcome = param(oXhr.url, "Outcome");
					var sNotes = param(oXhr.url, "Notes");
					var sTarget = sOutcome === "CP" ? "CP" : "RT";
					return headerAction(oXhr.url, oXhr, sTarget, false, function (oHeader, oXhr2) {
						if (sTarget === "RT" && !sNotes) {
							return odataError(oXhr2, "ZCSR/007",
								"Review notes are mandatory when returning a checklist");
						}
						var aReviews = getData("ReviewSet");
						aReviews.push({
							ReviewGuid: "rev-" + Date.now(),
							HeaderGuid: oHeader.HeaderGuid,
							Reviewer: "MOCKUSER",
							Outcome: sOutcome,
							Notes: sNotes || "",
							ReviewedAt: now()
						});
						setData("ReviewSet", aReviews);
						return false;
					});
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("ReassignChecklist(.*)"),
				response: function (oXhr) {
					var sNew = param(oXhr.url, "NewAnalyst");
					return headerAction(oXhr.url, oXhr, null, false, function (oHeader) {
						oHeader.Analyst = sNew;
						oHeader.ChangedAt = now();
						saveHeader(oHeader);
						return false;
					});
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("GenerateInstances(.*)"),
				response: function (oXhr) {
					// Mock keeps it simple: returns the existing instances of
					// the requested scope (generation itself is a backend concern).
					var sChktype = param(oXhr.url, "Chktype");
					var aHeaders = getData("ChecklistHeaderSet").filter(function (h) {
						return h.Chktype === sChktype;
					});
					return respondJson(oXhr, 200, { d: { results: aHeaders } });
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("TriggerAiTriage(.*)"),
				response: function (oXhr) {
					var sGuid = param(oXhr.url, "HeaderGuid");
					var aFlags = getData("AiFlagSet").filter(function (f) {
						return f.HeaderGuid === sGuid;
					});
					return respondJson(oXhr, 200, { d: { results: aFlags } });
				}
			});

			aRequests.push({
				method: "GET",
				path: new RegExp("ExportEvidence(.*)"),
				response: function (oXhr) {
					// Binary ZIP cannot be meaningfully mocked; respond with a
					// marker so the download wiring is testable.
					oXhr.respond(200,
						{ "Content-Type": "text/plain" },
						"mock evidence bundle");
					return true;
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("CopyCatalogVersion(.*)"),
				response: function (oXhr) {
					var sSource = param(oXhr.url, "SourceVersion");
					var aVersions = getData("CatalogVersionSet");
					var iNext = Math.max.apply(null, aVersions.map(function (v) {
						return parseInt(v.Version, 10);
					})) + 1;
					var sNext = ("0000" + iNext).slice(-4);
					var oNew = {
						Version: sNext, Status: "D", StatusText: "Draft",
						ValidFrom: null, CreatedBy: "MOCKUSER", CreatedAt: now()
					};
					aVersions.push(oNew);
					setData("CatalogVersionSet", aVersions);

					var aQuestions = getData("QuestionSet");
					aQuestions.filter(function (q) { return q.Version === sSource; })
						.forEach(function (q) {
							var oCopy = Object.assign({}, q, {
								Version: sNext, Editable: true, ValidFrom: null
							});
							aQuestions.push(oCopy);
						});
					setData("QuestionSet", aQuestions);
					return respondJson(oXhr, 200, { d: oNew });
				}
			});

			aRequests.push({
				method: "POST",
				path: new RegExp("ReleaseCatalogVersion(.*)"),
				response: function (oXhr) {
					var sVersion = param(oXhr.url, "Version");
					var sValidFrom = param(oXhr.url, "ValidFrom");
					if (!sValidFrom) {
						return odataError(oXhr, "ZCSR/015",
							"Valid-from date is required for release");
					}
					var aVersions = getData("CatalogVersionSet");
					var oVersion = aVersions.filter(function (v) {
						return v.Version === sVersion;
					})[0];
					if (!oVersion) {
						return odataError(oXhr, "ZCSR/010",
							"Catalog version " + sVersion + " not found");
					}
					if (oVersion.Status === "R") {
						return odataError(oXhr, "ZCSR/011",
							"Catalog version " + sVersion + " is already released");
					}
					var sDate = "/Date(" + Date.parse(sValidFrom) + ")/";
					oVersion.Status = "R";
					oVersion.StatusText = "Released";
					oVersion.ValidFrom = sDate;
					setData("CatalogVersionSet", aVersions);

					var aQuestions = getData("QuestionSet").map(function (q) {
						if (q.Version === sVersion) {
							q.Editable = false;
							q.ValidFrom = sDate;
						}
						return q;
					});
					setData("QuestionSet", aQuestions);
					return respondJson(oXhr, 200, { d: oVersion });
				}
			});

			oMockServer.setRequests(aRequests);
			oMockServer.start();
		},

		getMockServer: function () {
			return oMockServer;
		}
	};
});
