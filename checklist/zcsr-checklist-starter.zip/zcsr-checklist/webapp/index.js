sap.ui.define([
	"zcsr/checklist/localService/mockserver",
	"sap/ui/core/ComponentContainer"
], function (mockserver, ComponentContainer) {
	"use strict";

	// Local dev entry point: start the mockserver, then place the component.
	// When developing against the live gateway instead, skip mockserver.init()
	// and proxy /sap/opu/odata to the FES (see README "Live service").
	mockserver.init();

	new ComponentContainer({
		name: "zcsr.checklist",
		settings: { id: "zcsr.checklist" },
		manifest: true,
		height: "100%",
		async: true
	}).placeAt("content");
});
