sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"zcsr/checklist/model/roles",
	"sap/m/MessageBox"
], function (UIComponent, JSONModel, Device, roles, MessageBox) {
	"use strict";

	return UIComponent.extend("zcsr.checklist.Component", {

		metadata: { manifest: "json" },

		init: function () {
			UIComponent.prototype.init.apply(this, arguments);

			// device model
			var oDeviceModel = new JSONModel(Device);
			oDeviceModel.setDefaultBindingMode("OneWay");
			this.setModel(oDeviceModel, "device");

			// app state model: role + detail mode (edit | review)
			var oAppModel = new JSONModel({
				role: roles.getCurrentRole(),
				mode: "edit",
				busy: false,
				lastSaved: ""
			});
			this.setModel(oAppModel, "app");

			// central OData error handling (technical errors only —
			// business errors are handled per-request where they occur)
			var oModel = this.getModel();
			oModel.attachMetadataFailed(function () {
				MessageBox.error("Service metadata could not be loaded.");
			});

			this.getRouter().initialize();
		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				this._sContentDensityClass =
					Device.support.touch ? "sapUiSizeCozy" : "sapUiSizeCompact";
			}
			return this._sContentDensityClass;
		}
	});
});
